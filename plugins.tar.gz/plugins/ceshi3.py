#-*-coding:utf-8-*-
from qqbot import qqbotsched
import sqlite3

'''
conn = sqlite3.connect("wuso.db")
c= conn.cursor() 

#res1 = c.execute("select NAME,SIZE,LINK from jkwu")
#jkwulis = [ "片名:" + i[0] + "  大小:" + i[1] + "  链接  " + i[2] + " " for i in res1 ]

res3 = c.execute("select NAME,SIZE,LINK from guochan")
guochanlis = [ "片名:" + i[0] + "  大小:" + i[1] + "  链接  " + i[2] + " " for i in res3 ]
conn.commit()
conn.close()

diedai0 = zip(guochanlis)
diedai = (i for i in diedai0)

@qqbotsched(minute='0-59/1')
def mytask(bot):
    gl = bot.List('group',':like:百')
    if gl is not None:
        for group in gl:
            #bot.SendTo(group,"在线看福利，在QQ里就能打开链接，直接在线看，放心吧链接没毒，别人都这么看呢，就你out了！\n"+str(diedai.__next__())+"\n本群每分钟都放福利呢，你舍得退群吗？你肯定觉得视频看起来卡顿，那就对了，若是不卡那就不会免费放送。放心有解决之道的，请联系群主，他教你如何流畅看片，还会告诉你如何下载哦。。")
            bot.SendTo(group,"在线看福利，QQ里就能打开，直接在线看，放心链接没毒！\n"+str(diedai.__next__()).replace(",","\n").replace("'","").replace("(","").replace(")","").replace("干","*").replace("射","*").replace("爽","*").replace("交","*").replace("炮","*")+"\n感谢群主提供平台，在群里的每分钟，我都会为大家送上福利！")
'''





conn = sqlite3.connect("/root/.qqbot-tmp/plugins/wuso.db")
c= conn.cursor() 
res1 = c.execute("select NAME,SIZE,LINK from jk")
jklis = [i for i in res1]
res2 = c.execute("select NAME,SIZE,LINK from jkwu")
jkwulis = [i for i in res2]
res3 = c.execute("select NAME,SIZE,LINK from guochan")
guochanlis = [i for i in res3]
conn.commit()
conn.close()

conn = sqlite3.connect("/root/.qqbot-tmp/plugins/52av.db")
c= conn.cursor() 
res4 = c.execute("select NAME,LINK from ziyuanlist")
ziyuanllis = [i for i in res4]
conn.commit()
conn.close()

diedai0 = zip(guochanlis,ziyuanllis,jklis,jkwulis)
diedai = (i for i in diedai0)

@qqbotsched(minute='0-59/3')
def mytask(bot):
    gl = bot.List('group',':like:百')
    if gl is not None:
        for group in gl:
            #bot.SendTo(group,"在线看福利，在QQ里就能打开链接，直接在线看，放心吧链接没毒，别人都这么看呢，就你out了！\n"+str(diedai.__next__())+"\n本群每分钟都放福利呢，你舍得退群吗？你肯定觉得视频看起来卡顿，加入【在线福利群】：https://jq.qq.com/?_wv=1027&k=5g9dwVQ那就对了，若是不卡那就不会免费放送。放心有解决之道的，请联系群主，他教你如何流畅看片，还会告诉你如何下载哦。。")
            bot.SendTo(group,"戳链接在线看福利，放心链接没毒！\n"+str(diedai.__next__()).replace(",","\n").replace("'","").replace("(","").replace(")","")+"\n"+'''感谢群主提供平台，获取更多福利请加入 QQ号 3232584441拉你''')





















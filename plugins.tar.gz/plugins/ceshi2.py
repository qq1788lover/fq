#-*-coding:utf-8-*-
from qqbot import qqbotsched
import sqlite3

conn = sqlite3.connect("/root/.qqbot-tmp/plugins/wuso.db")
c= conn.cursor() 
res1 = c.execute("select NAME,SIZE,LINK from jk")
jklis = [i for i in res1]
res2 = c.execute("select NAME,SIZE,LINK from jkwu")
jkwulis = [i for i in res2]
res3 = c.execute("select NAME,SIZE,LINK from guochan")
guochanlis = [i for i in res3]
conn.commit()
conn.close()

conn = sqlite3.connect("/root/.qqbot-tmp/plugins/52av.db")
c= conn.cursor() 
res4 = c.execute("select NAME,LINK from ziyuanlist")
ziyuanllis = [i for i in res4]
conn.commit()
conn.close()

diedai0 = zip(guochanlis,ziyuanllis,jklis,jkwulis)
diedai = (i for i in diedai0)

@qqbotsched(minute='0-59/1')
def mytask(bot):
    gl = bot.List('group',':linke:百')
    if gl is not None:
        for group in gl:
            #bot.SendTo(group,"在线看福利，在QQ里就能打开链接，直接在线看，放心吧链接没毒，别人都这么看呢，就你out了！\n"+str(diedai.__next__())+"\n本群每分钟都放福利呢，你舍得退群吗？你肯定觉得视频看起来卡顿，那就对了，若是不卡那就不会免费放送。放心有解决之道的，请联系群主，他教你如何流畅看片，还会告诉你如何下载哦。。")
            bot.SendTo(group,"在线看福利，QQ里就能打开，直接在线看，放心链接没毒！\n"+str(diedai.__next__()).replace(",","\n").replace("'","").replace("(","").replace(")","")+"\n"+"感谢群主提供平台，在群里的每分钟，我都会为大家送上福利！")






#jklis =[ i[0].encode("utf-8")+"--"+i[1].encode("utf-8")+"--"+i[2].encode("utf-8") for i in res1]
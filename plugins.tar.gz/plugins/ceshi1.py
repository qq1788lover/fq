from qqbot import qqbotsched
import sqlite3

dbaddress = "/root/project/52av.db"
conn = sqlite3.connect(dbaddress)
c= conn.cursor() 
res1 = c.execute("select NAME,LINK from ziyuanlist")
ziyuanlis = [ str(i[0])+"---"+str(i[1]) for i in res1 ]
for i in ziyuanlis:
    print(i)